def fib_tab(n):
    if n <= 1:
        return n

    dp = [0] * (n + 1)

    dp[0] = 0
    dp[1] = 1

    for i in range(2, n + 1):
        dp[i] = dp[i - 1] + dp[i - 2]

    return dp[n]


def climb_stairs(n):
    if n <= 2:
        return n

    dp = [0] * (n + 1)

    dp[1] = 1
    dp[2] = 2

    for i in range(3, n + 1):
        dp[i] = dp[i - 1] + dp[i - 2]

    return dp[n]


def demo_dp_basics():
    print("\n=== DEMO 6: DP CƠ BẢN ===")

    print("Fibonacci:")
    for n in range(1, 8):
        print(f"fib_tab({n}) = {fib_tab(n)}")

    print("\nClimbing stairs:")
    for n in range(1, 8):
        print(f"climb_stairs({n}) = {climb_stairs(n)}")

    print("\nGiải thích:")
    print("- DP chia bài toán lớn thành các bài toán con.")
    print("- fib[n] = fib[n-1] + fib[n-2].")
    print("- climb_stairs[n] = climb_stairs[n-1] + climb_stairs[n-2].")


def build_combo_dp_table(prices, scores, B):
    n = len(prices)

    dp = []

    for i in range(n + 1):
        row = [0] * (B + 1)
        dp.append(row)

    for i in range(1, n + 1):
        price = prices[i - 1]
        score = scores[i - 1]

        for b in range(B + 1):
            dp[i][b] = dp[i - 1][b]

            if price <= b:
                choose = dp[i - 1][b - price] + score

                if choose > dp[i][b]:
                    dp[i][b] = choose

    return dp


def trace_combo_from_dp(dp, prices, scores, B):
    selected = []

    i = len(prices)
    b = B

    while i > 0:
        if dp[i][b] != dp[i - 1][b]:
            selected.append(i - 1)
            b -= prices[i - 1]

        i -= 1

    selected.reverse()
    return selected


def combo_knapsack_1d(prices, scores, B):
    dp = [0] * (B + 1)

    for i in range(len(prices)):
        price = prices[i]
        score = scores[i]

        for b in range(B, price - 1, -1):
            dp[b] = max(dp[b], dp[b - price] + score)

    return dp[B]


def demo_combo_knapsack_2d():
    print("\n=== DEMO 7A: COMBO KHUYẾN MÃI - KNAPSACK 2D ===")

    products = ["Áo", "Quần", "Giày", "Balo", "Mũ"]
    prices = [3, 4, 7, 6, 2]
    scores = [4, 5, 10, 7, 3]
    B = 10

    dp = build_combo_dp_table(prices, scores, B)
    selected = trace_combo_from_dp(dp, prices, scores, B)

    print("Danh sách sản phẩm:")
    for i in range(len(products)):
        print(f"{i}. {products[i]} - price={prices[i]}, score={scores[i]}")

    print("\nBudget:", B)
    print("Max score:", dp[len(products)][B])

    print("\nSản phẩm được chọn:")

    total_price = 0
    total_score = 0

    for i in selected:
        print(f"- {products[i]}")
        total_price += prices[i]
        total_score += scores[i]

    print("Tổng price:", total_price)
    print("Tổng score:", total_score)

    print("\nGiải thích:")
    print("- Đây là knapsack 0/1.")
    print("- Mỗi sản phẩm chỉ được chọn hoặc không chọn.")
    print("- Mục tiêu là tổng price <= budget và tổng score lớn nhất.")


def demo_combo_knapsack_1d():
    print("\n=== DEMO 7B: COMBO KHUYẾN MÃI - KNAPSACK 1D ===")

    prices = [3, 4, 7, 6, 2]
    scores = [4, 5, 10, 7, 3]
    B = 10

    dp_2d = build_combo_dp_table(prices, scores, B)

    result_2d = dp_2d[len(prices)][B]
    result_1d = combo_knapsack_1d(prices, scores, B)

    print("Kết quả 2D:", result_2d)
    print("Kết quả 1D:", result_1d)
    print("Hai kết quả giống nhau:", result_2d == result_1d)

    print("\nGiải thích:")
    print("- Bản 2D dễ truy vết sản phẩm được chọn.")
    print("- Bản 1D tiết kiệm bộ nhớ hơn khi budget lớn.")
    print("- Khi duyệt budget ngược, mỗi sản phẩm chỉ được dùng 1 lần.")


if __name__ == "__main__":
    demo_dp_basics()
    demo_combo_knapsack_2d()
    demo_combo_knapsack_1d()