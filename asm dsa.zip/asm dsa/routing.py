import heapq


def build_graph(edges):
    graph = {}

    for u, v, cost in edges:
        if u not in graph:
            graph[u] = []
        if v not in graph:
            graph[v] = []

        graph[u].append((v, cost))
        graph[v].append((u, cost))

    return graph


def dijkstra(graph, source):
    dist = {}
    parent = {}

    for v in graph:
        dist[v] = float("inf")
        parent[v] = None

    dist[source] = 0
    pq = [(0, source)]

    while pq:
        current_dist, u = heapq.heappop(pq)

        if current_dist > dist[u]:
            continue

        for v, cost in graph[u]:
            new_dist = current_dist + cost

            if new_dist < dist[v]:
                dist[v] = new_dist
                parent[v] = u
                heapq.heappush(pq, (new_dist, v))

    return dist, parent


def shortest_route(graph, source, target):
    if source not in graph or target not in graph:
        return float("inf"), []

    dist, parent = dijkstra(graph, source)

    if dist[target] == float("inf"):
        return float("inf"), []

    path = []
    cur = target

    while cur is not None:
        path.append(cur)
        cur = parent[cur]

    path.reverse()

    return dist[target], path


def make_set(vertices):
    parent = {}
    size = {}

    for v in vertices:
        parent[v] = v
        size[v] = 1

    return parent, size


def find(parent, v):
    if parent[v] != v:
        parent[v] = find(parent, parent[v])

    return parent[v]


def union(parent, size, a, b):
    root_a = find(parent, a)
    root_b = find(parent, b)

    if root_a == root_b:
        return False

    if size[root_a] < size[root_b]:
        root_a, root_b = root_b, root_a

    parent[root_b] = root_a
    size[root_a] += size[root_b]

    return True


def kruskal_mst(vertices, edges):
    parent, size = make_set(vertices)
    edges_sorted = sorted(edges)

    mst = []
    total_cost = 0

    for cost, u, v in edges_sorted:
        if union(parent, size, u, v):
            mst.append((u, v, cost))
            total_cost += cost

        if len(mst) == len(vertices) - 1:
            break

    return mst, total_cost


def demo_routing_shortest_path():
    print("\n=== DEMO 1: ROUTING SHORTEST PATH ===")

    edges = [
        ("WH1", "WH2", 4),
        ("WH1", "HN", 7),
        ("WH2", "HN", 2),
        ("WH2", "DN", 6),
        ("HN", "DN", 3),
        ("DN", "HCM", 5),
        ("HCM", "CT", 4),
        ("DN", "CT", 8)
    ]

    graph = build_graph(edges)

    source = "WH1"
    target = "HCM"

    cost, path = shortest_route(graph, source, target)

    print("Điểm bắt đầu:", source)
    print("Điểm kết thúc:", target)
    print("Đường đi ngắn nhất:", " -> ".join(path))
    print("Tổng chi phí:", cost)

    print("\nGiải thích:")
    print("- Mỗi kho hoặc điểm giao là một đỉnh.")
    print("- Mỗi tuyến đường là một cạnh có chi phí.")
    print("- Dijkstra dùng heapq để chọn tuyến có chi phí tạm thời nhỏ nhất.")


def demo_mst_network():
    print("\n=== DEMO 2: MST NETWORK ===")

    vertices = ["WH1", "WH2", "HN", "DN", "HCM", "CT"]

    edges = [
        (4, "WH1", "WH2"),
        (7, "WH1", "HN"),
        (2, "WH2", "HN"),
        (6, "WH2", "DN"),
        (3, "HN", "DN"),
        (5, "DN", "HCM"),
        (4, "HCM", "CT"),
        (8, "DN", "CT")
    ]

    mst, total_cost = kruskal_mst(vertices, edges)

    print("Các đường truyền được chọn:")

    for u, v, cost in mst:
        print(f"{u} - {v}, chi phí = {cost}")

    print("Tổng chi phí lắp đặt:", total_cost)

    print("\nGiải thích:")
    print("- Kruskal sắp xếp các cạnh theo chi phí tăng dần.")
    print("- DSU dùng để kiểm tra 2 kho đã cùng nhóm chưa.")
    print("- Nếu cùng nhóm thì bỏ cạnh để tránh tạo chu trình.")
    print("Nhận xét: Đây là bộ khung tối thiểu, các tuyến giao hàng chi tiết dùng Dijkstra.")


if __name__ == "__main__":
    demo_routing_shortest_path()
    demo_mst_network()