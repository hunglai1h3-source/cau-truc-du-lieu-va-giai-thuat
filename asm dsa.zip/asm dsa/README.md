# asm dsa

## Mô tả
Project mô phỏng hệ thống hậu cần POLY-SHIP bằng các cấu trúc dữ liệu và giải thuật.

## Các phần đã làm
1. Routing shortest path bằng Dijkstra.
2. MST network bằng Kruskal + DSU.
3. Hash table đơn hàng.
4. Hashing tổng hợp: group anagrams, longest consecutive, subarray sum = k.
5. Rolling hash tìm pattern trong log.
6. DP cơ bản: Fibonacci, Climbing Stairs.
7. Combo khuyến mãi bằng Knapsack 0/1 bản 2D và 1D.

## Cấu trúc file
- routing.py: Dijkstra, shortest route, DSU, Kruskal MST.
- hashing_tools.py: Hash table, group anagrams, longest consecutive, prefix sum, rolling hash.
- promo_optimizer.py: Fibonacci, climbing stairs, knapsack 2D và 1D.
- main_assignment.py: Menu chạy demo.

## Cách chạy
Mở terminal tại thư mục project rồi chạy:

```bash
python main_assignment.py