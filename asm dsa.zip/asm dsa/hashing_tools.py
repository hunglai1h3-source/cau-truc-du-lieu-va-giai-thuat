class OrderHashTable:
    def __init__(self, size=10):
        self.size = size
        self.table = []

        for i in range(size):
            self.table.append([])

    def hash_function(self, order_id):
        total = 0

        for ch in order_id:
            total += ord(ch)

        return total % self.size

    def insert(self, order_id, order_data):
        index = self.hash_function(order_id)
        bucket = self.table[index]

        for i in range(len(bucket)):
            old_id, old_data = bucket[i]

            if old_id == order_id:
                bucket[i] = (order_id, order_data)
                return

        bucket.append((order_id, order_data))

    def get(self, order_id):
        index = self.hash_function(order_id)
        bucket = self.table[index]

        for old_id, old_data in bucket:
            if old_id == order_id:
                return old_data

        return None

    def remove(self, order_id):
        index = self.hash_function(order_id)
        bucket = self.table[index]

        for i in range(len(bucket)):
            old_id, old_data = bucket[i]

            if old_id == order_id:
                bucket.pop(i)
                return True

        return False

    def display(self):
        for i in range(self.size):
            print(f"Bucket {i}: {self.table[i]}")


def demo_order_hash_table():
    print("\n=== DEMO 3: HASH TABLE ĐƠN HÀNG ===")

    table = OrderHashTable(5)

    table.insert("ORD001", {"name": "An", "city": "HN", "total": 200})
    table.insert("ORD002", {"name": "Binh", "city": "HCM", "total": 350})
    table.insert("ORD003", {"name": "Chi", "city": "DN", "total": 150})

    print("Sau khi thêm đơn hàng:")
    table.display()

    print("\nTìm ORD002:")
    print(table.get("ORD002"))

    print("\nTìm ORD999:")
    print(table.get("ORD999"))

    print("\nXóa ORD003:")
    print(table.remove("ORD003"))

    print("\nSau khi xóa:")
    table.display()

    print("\nGiải thích:")
    print("- Hash table biến order_id thành vị trí bucket.")
    print("- Nếu nhiều đơn hàng trùng bucket thì dùng separate chaining.")
    print("- Vì vậy tra cứu đơn hàng nhanh hơn duyệt list thông thường.")


def group_coupon_anagrams(codes):
    groups = {}

    for code in codes:
        key = "".join(sorted(code))

        if key not in groups:
            groups[key] = []

        groups[key].append(code)

    return list(groups.values())


def longest_consecutive_days(days):
    day_set = set(days)
    best = 0

    for day in day_set:
        if day - 1 not in day_set:
            current = day
            length = 1

            while current + 1 in day_set:
                current += 1
                length += 1

            if length > best:
                best = length

    return best


def count_revenue_windows(revenues, k):
    prefix_count = {0: 1}
    prefix_sum = 0
    count = 0

    for money in revenues:
        prefix_sum += money
        need = prefix_sum - k

        if need in prefix_count:
            count += prefix_count[need]

        if prefix_sum not in prefix_count:
            prefix_count[prefix_sum] = 0

        prefix_count[prefix_sum] += 1

    return count


def rolling_hash_search(text, pattern):
    if len(pattern) == 0 or len(pattern) > len(text):
        return []

    base = 256
    mod = 1000000007

    n = len(text)
    m = len(pattern)

    pattern_hash = 0
    window_hash = 0
    power = 1

    for i in range(m - 1):
        power = (power * base) % mod

    for i in range(m):
        pattern_hash = (pattern_hash * base + ord(pattern[i])) % mod
        window_hash = (window_hash * base + ord(text[i])) % mod

    result = []

    for i in range(n - m + 1):
        if pattern_hash == window_hash:
            if text[i:i + m] == pattern:
                result.append(i)

        if i < n - m:
            left = ord(text[i])
            right = ord(text[i + m])

            window_hash = (window_hash - left * power) % mod
            window_hash = (window_hash * base + right) % mod

    return result


def demo_hashing_general():
    print("\n=== DEMO 4: HASHING TỔNG HỢP ===")

    codes = ["SAVE10", "AVES10", "SHIP20", "PISH20", "HELLO"]

    print("\nGroup anagrams:")
    groups = group_coupon_anagrams(codes)

    for group in groups:
        print(group)

    print("Ứng dụng: phát hiện mã coupon khác tên nhưng giống cấu trúc ký tự.")

    days = [1, 2, 3, 7, 8, 9, 10, 15]
    print("\nDanh sách ngày:", days)
    print("Chuỗi ngày liên tiếp dài nhất:", longest_consecutive_days(days))

    revenues = [3, 4, 7, 2, -3, 1, 4, 2]
    k = 7
    print("\nDoanh thu:", revenues)
    print("Số đoạn có tổng =", k, "là:", count_revenue_windows(revenues, k))

    print("\nGiải thích:")
    print("- Group anagrams dùng dict với key là chuỗi sau khi sort.")
    print("- Longest consecutive dùng set để kiểm tra ngày liên tiếp.")
    print("- Subarray sum = k dùng prefix sum và hash map.")


def demo_rolling_coupon_search():
    print("\n=== DEMO 5: ROLLING HASH ===")

    text = "user used SAVE10 and another user used SHIP20 then SAVE10 again"
    patterns = ["SAVE10", "SHIP20", "WELCOME"]

    print("Log:", text)

    for pattern in patterns:
        print(pattern, "xuất hiện tại vị trí:", rolling_hash_search(text, pattern))

    print("\nGiải thích:")
    print("- Rolling hash dùng cửa sổ trượt trên chuỗi log.")
    print("- Mỗi lần trượt chỉ cập nhật hash, không cần tính lại toàn bộ từ đầu.")


if __name__ == "__main__":
    demo_order_hash_table()
    demo_hashing_general()
    demo_rolling_coupon_search()